import UIKit
import Flutter
import AVFoundation
import Flutter

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
    let TRANSCODER_CHANNEL = "transcoder";
    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        let flutterViewController: FlutterViewController = window?.rootViewController as! FlutterViewController
        
        let channel = FlutterMethodChannel(name: TRANSCODER_CHANNEL, binaryMessenger: flutterViewController.binaryMessenger)
        channel.setMethodCallHandler { [weak self] call, result in
            guard let self = self else { return }
            
            switch call.method {
            case "merge":
                self.mergeVideos(call: call, result: result)
            case "extractMetadata":
                if let filePath = call.arguments as? String {
                    let asset = AVAsset(url: URL(fileURLWithPath: filePath))
                    let videoTrack = asset.tracks(withMediaType: .video).first
                    
                    let width = Int(videoTrack?.naturalSize.width ?? 0)
                    let height = Int(videoTrack?.naturalSize.height ?? 0)
                    let transform = videoTrack?.preferredTransform ?? .identity
                    let rotation = atan2(transform.b, transform.a) * CGFloat(180.0 / .pi)
                    let duration = Int(asset.duration.seconds)
                    let size = (try? FileManager.default.attributesOfItem(atPath: filePath)[.size] as? Int64) ?? 0
                    
                    let data: [String: Any] = [
                        "width": width,
                        "height": height,
                        "rotation": rotation,
                        "duration": duration,
                        "size": size
                    ]
                    
                    result(data)
                } else {
                    result(FlutterError(code: "0", message: "Invalid arguments", details: nil))
                }
            default:
                result(FlutterMethodNotImplemented)
            }
        }
        
        GeneratedPluginRegistrant.register(with: self);
          return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
    func mergeVideos(call: FlutterMethodCall, result: @escaping FlutterResult) {
        // Retrieve the necessary arguments
        guard let arguments = call.arguments as? [String: Any],
              let urls = arguments["urls"] as? [String],
              let audioUrl = arguments["audioUrl"] as? String,
              let videoSpeed = arguments["videoSpeed"] as? Double,
              let isFrontFacing = arguments["isFrontFacing"] as? Bool else {
            result(FlutterError(code: "0", message: "Invalid arguments", details: nil))
            return
        }
        
        let newPath = getPath().appendingPathComponent("append.mp4").path
        let outputFilePath = newPath
        
        if FileManager.default.fileExists(atPath: outputFilePath) {
            do {
                try FileManager.default.removeItem(atPath: outputFilePath)
                print("Existing file deleted: \(outputFilePath)")
            } catch {
                let deletionError = "Failed to delete existing file: \(error.localizedDescription)"
                print(deletionError)
                result(FlutterError(code: "0", message: "Failed to delete existing file", details: error.localizedDescription))
                return
            }
        }
        
        DispatchQueue.global().async {
            var videoList = [URL]()
            
            for url in urls {
                let fileURL = URL(fileURLWithPath: url)
                if FileManager.default.fileExists(atPath: fileURL.path),
                   let asset = AVURLAsset(url: fileURL) as AVAsset?,
                   let _ = asset.tracks(withMediaType: .video).first {
                    videoList.append(fileURL)
                }
            }
            
            do {
                var inMovies = [AVAsset]()
                videoList.reverse()
                for videoURL in videoList {
                    let asset = AVURLAsset(url: videoURL)
                    inMovies.append(asset)
                }
                
                var videoTracks = [AVAssetTrack]()
                var audioTracks = [AVAssetTrack]()
                
                for movie in inMovies {
                    for track in movie.tracks {
                        if track.mediaType == .audio {
                            audioTracks.append(track)
                        }
                        if track.mediaType == .video {
                            videoTracks.append(track)
                        }
                    }
                }
                
                let composition = AVMutableComposition()
                
                // Merge video tracks
                let videoCompositionTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)
                for videoTrack in videoTracks {
                    try videoCompositionTrack?.insertTimeRange(videoTrack.timeRange, of: videoTrack, at: .zero)
                }
                
                // Merge audio tracks or add external audio
                var audioCompositionTrack: AVMutableCompositionTrack?
                if audioUrl.isEmpty {
                    // Merge audio tracks
                    audioCompositionTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
                    for audioTrack in audioTracks {
                        try audioCompositionTrack?.insertTimeRange(audioTrack.timeRange, of: audioTrack, at: .zero)
                    }
                } else {
                    let audioURL = URL(fileURLWithPath: audioUrl)

                    // Add audio merging using the audioUrl
                        print("Audio URL: ", audioURL)

                    do {
                           let audioAsset = try AVURLAsset(url: audioURL)
                           let audioTrack = audioAsset.tracks(withMediaType: .audio).first

                           if let audioTrack = audioTrack {
                               audioCompositionTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
                               
                               // Limit the duration of the audio track to match the video duration
                               let videoDuration = CMTimeRange(start: .zero, duration: videoCompositionTrack?.timeRange.duration ?? .zero)
                               let audioDuration = audioTrack.timeRange.duration
                               let duration = CMTimeMinimum(videoDuration.duration, audioDuration)
                               let timeRange = CMTimeRange(start: audioTrack.timeRange.start, duration: duration)
                               
                               try audioCompositionTrack?.insertTimeRange(timeRange, of: audioTrack, at: .zero)
                           }
                       } catch {
                           print("Error creating AVURLAsset: ", error.localizedDescription)
                       }
                }
                
                let exportSession = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality)
                // Check if audioCompositionTrack is not nil before initializing audioMixInputParameters
                if let audioCompositionTrack = audioCompositionTrack {
                    let audioMixInputParameters = AVMutableAudioMixInputParameters(track: audioCompositionTrack)
                    audioMixInputParameters.setVolume(1.0, at: .zero) // Adjust audio volume if needed

                    let audioMix = AVMutableAudioMix()
                    audioMix.inputParameters = [audioMixInputParameters]

                    exportSession?.audioMix = audioMix
                }

                
                exportSession?.outputFileType = .mp4
                exportSession?.outputURL = URL(fileURLWithPath: newPath)
                exportSession?.shouldOptimizeForNetworkUse = true
                
                let audioMixInputParameters = AVMutableAudioMixInputParameters(track: audioCompositionTrack)
                audioMixInputParameters.setVolume(1.0, at: .zero) // Adjust audio volume if needed
                
                let audioMix = AVMutableAudioMix()
                audioMix.inputParameters = [audioMixInputParameters]
                
                exportSession?.audioMix = audioMix
                
                exportSession?.exportAsynchronously(completionHandler: {
                    DispatchQueue.main.async {
                        switch exportSession?.status {
                        case .completed:
                            result(newPath)
                        case .failed, .cancelled:
                            if let error = exportSession?.error {
                                result(FlutterError(code: "0", message: error.localizedDescription, details: error))
                            } else {
                                result(FlutterError(code: "0", message: "Video merging failed", details: nil))
                            }
                        default:
                            result(FlutterError(code: "0", message: "Video merging failed", details: nil))
                        }
                    }
                })
            } catch {
                result(FlutterError(code: "0", message: error.localizedDescription, details: error))
            }
        }
    }


    
    func getPath() -> URL {
        let temporaryDirectoryURL = URL(fileURLWithPath: NSTemporaryDirectory())
        return temporaryDirectoryURL
    }
}

